<?php

namespace Database\Seeders;

use App\Models\Course;
use App\Models\Language;
use App\Models\Question;
use App\Models\User;
use App\Models\Video;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Spatie\Permission\Models\Role;

class CourseSeeder extends Seeder
{

    protected array $videos = [
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4",
    ];

    protected array $lang = [
        'Scrach',
        'Python',
        'Ruby',
    ];

    /**
     * Run the database seeds.
     */
    public function run(): void
    {

        Role::create(['name' => 'parent']);
        Role::create(['name' => 'child']);

        for ($x = 0; $x <= 10; $x++) {
            $user = User::create([
                'username' => fake()->name(),
                'email' => fake()->unique()->safeEmail(),
                'email_verified_at' => now(),
                'password' => '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', // password
                'remember_token' => Str::random(10),
            ]);

            $user->assignRole('parent');
        }

        for ($x = 0; $x < 3; $x++) {
            Language::create([
                'title' => $this->lang[$x],
                'slug' => fake()->slug(),
            ]);
        }

        for ($x = 0; $x < 10; $x++) {
            Course::create([
                'title' => fake()->sentence(),
                'slug' => fake()->slug(),
                'language_id' => rand(min: 1, max: 3),
            ]);
        }

        for ($x = 0; $x < 20; $x++) {
            Video::create([
                'title' => fake()->sentence(),
                'slug' => fake()->slug(),
                'location' => $this->videos[array_rand($this->videos)],
                'course_id' => rand(min: 1, max: 10),
            ]);
        }

        $choice = ['a', 'b', 'c'];
        $img = [null, fake()->imageUrl(width: 300, height: 300)];

        for ($x = 0; $x < 100; $x++) {
            Question::create([
                'title' => fake()->sentence(),
                'slug' => fake()->slug(),
                'choice_one' => fake()->sentence(nbWords: rand(min: 2, max: 10)),
                'choice_two' => fake()->sentence(nbWords: rand(min: 2, max: 10)),
                'choice_three' => fake()->sentence(nbWords: rand(min: 2, max: 10)),
                'correct_answer' => $choice[array_rand($choice)],
                'code_image_url' => $img[array_rand($img)],
                'course_id' => rand(min: 1, max: 10),
            ]);
        }

//        for ($x = 0; $x < 5000; $x++) {
//            Progress::create([
//                'user_id' => rand(min: 1, max: 10),
//                'question_id' => rand(min: 1, max: 1000),
//                'select_answer' => $choice[array_rand($choice)],
//            ]);
//        }

    }
}
